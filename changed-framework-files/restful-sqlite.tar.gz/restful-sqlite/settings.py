
# Port to listen on for HTTP connections
port=8888

# Path to sqlite databases
data_path='/home/owls/webservice/'

# Cookie secret
cookie_secret='You should really change this'
